module.exports = (sequelize, dataTypes) => {
    let alias = "movies";
    let cols = {
        id: {
            type: dataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false
        },
        title: {
            type: dataTypes.STRING,
            allowNull: false
        },
        length: {
            type: dataTypes.INTEGER,
            allowNull: true,
            default: 0
        }
    }
    let config = {
        tableName: "movies",
        underscored: true,
        timestamps: true
    }


const movie = sequelize.define(alias,cols,config);

return movie;

}