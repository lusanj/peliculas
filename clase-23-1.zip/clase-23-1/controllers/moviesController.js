
let db = require('../database/models');

module.exports = {
    list: function(req,res){
        db.movies.findAll()
            .then(data => {
                res.render('movies', {movies:data})
            })
            .catch(err => {
                res.send('Hubo un error, intentalo mas tarde')
            })
    },
    show: function(req,res){
        //buscar una pelicula por id
        db.movies.findByPk(req.params.id)
            .then(data => {
                res.render('movies/detalle', {movie:data})
            })
            .catch(err => {
                res.send('Hubo un error, intentalo mas tarde')
            })
    }
}

