var express = require('express');
var router = express.Router();

var moviesController = require('../controllers/moviesController');

/* GET home page. */
router.get('/', moviesController.list);

router.get('/xd', function(req, res, next) {
    res.render('movies', { title: 'movies' });
  });

module.exports = router;
